<!-- footer -->
<footer class="footer">
	<div class="container-fluid">
		<nav class="pull-left">
			<ul>
				<li>
					<a href="admin/user/listuser">
						Trang chủ
					</a>
				</li>

			</ul>
		</nav>
	</div>
</footer>	
<!-- end footer -->
<!-- footer -->
<footer class="footer">
	<div class="container-fluid">
		<nav class="pull-left">
			<ul>
				<li>
					<a href="expert/injury/listinjury">
						Trang chủ
					</a>
				</li>

			</ul>
		</nav>
	</div>
</footer>	
<!-- end footer -->